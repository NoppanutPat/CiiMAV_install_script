#!/usr/bin/env python

import sys
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge


def callback(data):
    msg = data
    bridge = CvBridge()
    frame = bridge.imgmsg_to_cv2(msg, "bgr8")
    cv2.imshow("frame",frame)
    cv2.waitKey(1)

    # rospy.loginfo(rospy.get_caller_id() + "I heard %s", data.data)

def listenner():
    rospy.init_node('listener',anonymous=True)
    rospy.Subscriber("Video", Image, callback)
    rospy.spin()

if __name__ == "__main__":
    listenner()