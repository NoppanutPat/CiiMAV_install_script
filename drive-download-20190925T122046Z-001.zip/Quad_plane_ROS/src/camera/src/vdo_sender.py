#!/usr/bin/env python

import sys
import cv2
from cv_bridge import CvBridge
from sensor_msgs.msg import Image
import rospy


def publisher():
    cap = cv2.VideoCapture(0)
    pub = rospy.Publisher("Video",Image,queue_size=1)
    rospy.init_node('image_pub',anonymous=True)
    while not rospy.is_shutdown():
        ret,frame = cap.read()
        print("Start")
        if ret == True:
            # print("Show image")
            # cv2.imshow("frame",frame)
            print(frame)
            bridge = CvBridge()
            imgMsg = bridge.cv2_to_imgmsg(frame, "bgr8")
            pub.publish(imgMsg)
            #pub.publish(frame.shape)
            rospy.Rate(30).sleep()
            if cv2.waitKey(1) & 0xFF == ord('q'):
                break

    cap.release()
    cv2.destroyAllWindows()

    
if __name__ == "__main__":
    
    publisher()

