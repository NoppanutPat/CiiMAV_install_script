#!/usr/bin/env python

import rospy
import sys
from std_msgs.msg import Float64MultiArray
import numpy as np
import pandas as pd

def listener():
    rospy.init_node("save_coor",anonymous=True)
    rospy.Subscriber("Coor",Float64MultiArray,callback)
    rospy.spin()

def callback(data):
    xRes,yRes,lat,lon,alt = data.data
    df = pd.read_csv("../../main_mission/src/data.csv")
    df.loc[len(df)] = [xRes,yRes,lat,lon,alt]
    df.to_csv("../../main_mission/src/data.csv",index=None)


if __name__ == "__main__":
    listener()
    
