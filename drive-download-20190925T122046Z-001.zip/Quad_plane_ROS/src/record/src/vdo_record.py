#!/usr/bin/env python

import sys
import rospy
import cv2
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import numpy as np 

out = cv2.VideoWriter('output.avi',cv2.VideoWriter_fourcc('M','J','P','G'), 10, (1920,1080))

def callback(data):
    msg = data
    bridge = CvBridge()
    frame = bridge.imgmsg_to_cv2(msg, "bgr8")
    vdo_record(out,frame)


def listener():
    rospy.init_node("record",anonymous=True)
    rospy.Subscriber("Video",Image,callback)
    rospy.spin()

def vdo_record(out,frame):
    out.write(frame)
    cv2.imshow('frame',frame)


if __name__ == "__main__":
    listener()



