#!/usr/bin/env python

import sys
import cv2
import rospy
from dronekit import connect, VehicleMode
from std_msgs.msg import String

connection_string = "/dev/ttyACM0"
baud_rate = 115200

vehicle = connect(connection_string, baud=baud_rate, wait_ready=True)
vehicle.wait_ready('autopilot_version')

def talker():
    pub = rospy.Publisher('Altitude', String, queue_size=1)
    rospy.init_node('altitudeSender', anonymous=True)
    rate = rospy.Rate(10)
    while not rospy.is_shutdown():
        posdata = str(vehicle.location.global_relative_frame).split(':')
        lat, lon, alt = posdata[1].split(',')
        rospy.loginfo([lat, lon, alt])
        pub.publish([lat, lon, alt])
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass

