from dronekit import connect, VehicleMode, LocationGlobalRelative
from serial import *
import time
import pandas as pd
import numpy as np

def Change_MODE(vehicle,mode):
    vehicle.mode = VehicleMode(mode)

def Get_YAW(vehicle):
	yaw = float((str(vehicle.attitude).split(':')[1].split(',')[1])[4:])
	return yaw

def Armed(vehicle):
	print('........Check Armed........')
	while True:
		print(">>>> Change Mode to 'GUIDED' <<<<")
		vehicle.mode = VehicleMode("GUIDED")		
    	        print(">>>> ARMED <<<<")
    	        vehicle.armed = True
    	        if vehicle.armed:
    		    print(">>>> Already Armed <<<<")
      		    break
    	        else:
		    continue
    	        time.sleep(2)

def Takeoff(vehicle,alt):
        while(vehicle.armed == False):
            print "Please armed ...."
            time.sleep(2)
            continue
 	print('>>>>>>>> Take off <<<<<<<<<')
	vehicle.simple_takeoff(alt)
	time.sleep(4)
	print(">>>> Change mode to 'QHOVER' <<<<")
	vehicle.mode = VehicleMode("QHOVER")
	print('>>>> Complete Takeoff <<<<')

def Change_Alt(vehicle,alt):
	posdata = str(vehicle.location.global_relative_frame).split(':')
	poslat, poslon, Alt = posdata[1].split(',')
	lat = float(str(poslat)[4:])
  	lon = float(str(poslon)[4:])
  	print(">>>> Change mode to 'GUIDED' <<<<")
  	vehicle.mode = VehicleMode("GUIDED")
  	print(">>>> Going to ALT:"+str(alt)+" <<<<")
  	a_location = LocationGlobalRelative(lat,lon,alt)
  	vehicle.simple_goto(a_location)
  	time.sleep(7)
  	print(">>>> Change mode to 'QHOVER' <<<<")
  	vehicle.mode = VehicleMode("QHOVER")
  	print(">>>> Complete Change ALT <<<<")


def goto(vehicle,lat,lon,alt):
 	print(">>>> Change mode to 'GUIDED' <<<<")
  	vehicle.mode = VehicleMode("GUIDED")
  	a_location = LocationGlobalRelative(lat,lon,alt)
  	print('>>>>>>> Going to  '+str(lat)+','+str(lon)+','+str(alt)+' <<<<<<<<<<')
  	vehicle.simple_goto(a_location)
  	time.sleep(7)
  	print(">>> Change mode to 'QHOVER' <<<<")
  	vehicle.mode = VehicleMode("QHOVER")
  	print('>>>> Complete GOTO <<<<')

def land(vehicle):
  	print(">>>> LANDING <<<<")
  	vehicle.mode = VehicleMode("LAND")
  	print(">>>> Landing Complete <<<<")

def get_GPSvalue(vehicle):
	posdata = str(vehicle.location.global_relative_frame).split(':')
  	poslat, poslon, Alt = posdata[1].split(',')
  	lat = float(str(poslat)[4:])
  	lon = float(str(poslon)[4:])
    	alt = float(str(Alt)[4:])
  	return [lat,lon,alt]

def drop(vehicle,serNo,rpm):
	msg = vehicle.message_factory.command_long_encode(
	0, 0,    # target_system, target_component
	mavutil.mavlink.MAV_CMD_DO_SET_SERVO, #command
	0, #confirmation
	serNo,    # servo number
	rpm,          # servo position between 1000 and 2000
	0, 0, 0, 0, 0)    # param 3 ~ 7 not used
	# send command to vehicle
	vehicle.send_mavlink(msg)
	print('Success')

def saveCOOR(vehicle,xRes,yRes,lat,lon,alt):
    df = pd.read_csv("data.csv")
    df.loc[len(df)] = [xRes,yRes,lat,lon,alt]
    df.to_csv("data.csv",index=None)
    

