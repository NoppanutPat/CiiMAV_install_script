#!/usr/bin/env python

import sys
import rospy
from std_msgs.msg import Float64MultiArray
from dronekit import connect, VehicleMode
from mission_lib import *
from math import sin,cos,atan2,pi,sqrt

connection_string = "/dev/ttyACM0"
baud_rate = 115200
vehicle = connect(connection_string, baud=baud_rate, wait_ready=True)
vehicle.wait_ready('autopilot_version')

def listener():
    rospy.init_node("go_to",anonymous=True)
    rospy.Subscriber("pic_xy",Float64MultiArray,callback)
    rospy.spin()

def callback(data):
    
    xRes , yRes, area_res = data.data
    yaw = 0
    yaw = Get_YAW(vehicle)

    want_go = 0.0001

    if xRes == 100 and yRes == 100: #Can't find
        if vehicle.mode == "GUIDE" or vehicle.mode == "STABILIZE":
            vehicle.mode = VehicleMode("AUTO")
        else:
            return 0

    if abs(xRes) < 0.03 and abs(yRes) < 0.03:
        print(">>> Change mode to 'QLOITER' <<<<")
  	vehicle.mode = VehicleMode("LOITER")
        Change_Alt(vehicle,10)
        print ">>>>>>>>>>>>>>>> DROPPP >>>>>>>>>>>>>>>>>"

    R = sqrt((xRes**2)+(yRes**2))

    # print "atan2(yRes,xRes) : ", (atan2(yRes,xRes)*180/pi)

    atann = atan2(yRes,xRes)

    # if atann < 0:
    #     atann += 2*pi

    if yaw > 0 and yaw <= pi/2:
        n_go = yRes*cos(yaw) - xRes*sin(yaw)
        e_go = yRes*sin(yaw) + xRes*cos(yaw)

    elif yaw > pi/2 and yaw <= pi:
        n_go = xRes*sin(2*pi-yaw) + yRes*cos(2*pi - yaw)
        e_go = xRes*cos(2*pi-yaw) - yRes*sin(2*pi - yaw)

    elif yaw > pi and yaw <= 3*pi/2:
        n_go = xRes*sin(yaw - pi) - yRes*cos(yaw - pi)
        e_go = -xRes*cos(yaw - pi) - yRes*sin(yaw - pi)

    elif yaw > 3*pi/2 and yaw < 2*pi:
        n_go = -xRes*cos(yaw - pi/2) - yRes*sin(yaw - pi/2)
        e_go = yRes*cos(yaw - pi/2) - xRes*sin(yaw - pi/2)

    elif yaw == 0:
        n_go = yRes
        e_go = xRes

    if abs(n_go) < 0.0000001:
        n_go = 0

    if abs(e_go) < 0.0000001:
        e_go = 0

    n_go = want_go * n_go
    e_go = want_go * e_go
    
    poslat,poslon,Alt = get_GPSvalue(vehicle)

    print "xRes , yRes : ",xRes," , ",yRes

    print "yaw : ",yaw

    print "n_want_go , e_want_go : ",n_go," , ",e_go

    print "n_go , e_go : ",n_go+poslat," , ",e_go+poslon

    print "--------------------------------------------------"


    if abs(xRes) > 0.05 and abs(yRes) > 0.05 :
        if vehicle.mode == "AUTO" or vehicle.mode == "STABILIZE":
            poslat,poslon,Alt = get_GPSvalue(vehicle)
            if Alt > 13:
                goto(vehicle, poslat+n_go,poslon+e_go,Alt-1)
            else:
                goto(vehicle, poslat+n_go,poslon+e_go,Alt)


if __name__ == "__main__":
    Takeoff(vehicle,30)
    vehicle.mode = VehicleMode("AUTO")
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
