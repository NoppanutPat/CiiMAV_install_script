from mission_lib import *
import time


connection_string = "/dev/ttyACM0"
baud_rate = 115200
vehicle = connect(connection_string, baud=baud_rate, wait_ready=True)
vehicle.wait_ready('autopilot_version')

print "Before : ",vehicle.mode
vehicle.mode = VehicleMode("ALT_HOLD")
time.sleep(2)
print "After : ",vehicle.mode
