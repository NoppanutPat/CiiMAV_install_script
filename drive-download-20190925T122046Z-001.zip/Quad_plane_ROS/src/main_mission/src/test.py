from math import sin,cos,atan2,pi,atan,sqrt

yaw = 7*pi/4

while True:

    on_line = 0

    want_go_x = 0.001
    want_go_y = 0.001

    xRes = float(input("x: "))
    yRes = float(input("y: "))

    if xRes == 0 and yRes == 0:
        continue

    R = sqrt((xRes**2)+(yRes**2))

    print "atan2(yRes,xRes) : ", (atan2(yRes,xRes)*180/pi)

    atann = atan2(yRes,xRes)

    # if atann < 0:
    #     atann += 2*pi

    if yaw > 0 and yaw <= pi/2:
        n_go = yRes*cos(yaw) - xRes*sin(yaw)
        e_go = yRes*sin(yaw) + xRes*cos(yaw)

    elif yaw > pi/2 and yaw <= pi:
        n_go = xRes*sin(2*pi-yaw) + yRes*cos(2*pi - yaw)
        e_go = xRes*cos(2*pi-yaw) - yRes*sin(2*pi - yaw)

    elif yaw > pi and yaw <= 3*pi/2:
        n_go = xRes*sin(yaw - pi) - yRes*cos(yaw - pi)
        e_go = -xRes*cos(yaw - pi) - yRes*sin(yaw - pi)

    elif yaw > 3*pi/2 and yaw < 2*pi:
        n_go = -xRes*cos(yaw - pi/2) - yRes*sin(yaw - pi/2)
        e_go = yRes*cos(yaw - pi/2) - xRes*sin(yaw - pi/2)

    elif yaw == 0:
        n_go = yRes
        e_go = xRes

    if abs(n_go) < 0.0000001:
        n_go = 0

    if abs(e_go) < 0.0000001:
        e_go = 0

    n_go = want_go_y * n_go
    e_go = want_go_x * n_go

    if n_go == 0:
        print "e_go : ",e_go

    if e_go == 0:
        print "n_go : ",n_go

    # n_go = want_go_y*R*cos(atann+yaw)
    
    # e_go = want_go_x*R*sin(atann+yaw)

    # print "e_go : ",e_go
    # print "n_go : ",n_go
        
    # e_go = want_go*(cos(a*cos(yaw-((pi/2)-a)))+sin(a)*cos(yaw+a))

    # n_go = want_go*(cos(a*sin(yaw-((pi/2)-a)))+sin(a)*sin(yaw+a))

    

    

    