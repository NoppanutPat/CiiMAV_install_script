#!/usr/bin/env python

import sys
import rospy
import cv2
from sensor_msgs.msg import Image
from std_msgs.msg import String,Float64MultiArray
from cv_bridge import CvBridge
import time
import numpy as np 

pub = rospy.Publisher("pic_xy",Float64MultiArray,queue_size=1)
imgPub = rospy.Publisher("/Video/result",Image,queue_size=1)
maskPub = rospy.Publisher("/Video/mask",Image,queue_size=1)

def findColor(mask, blurred):
    r, c, ch = blurred.shape
    ret, thresh = cv2.threshold(mask, 127, 255, 0)
    _, contours, hierarchy = cv2.findContours(thresh, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
    frame_color = (0, 0, 0)
    color_send = 999.0
    for cnt in contours:
        xRes = 100.0
        yRes = 100.0
        rect = cv2.minAreaRect(cnt)
        center, wh, _ = cv2.minAreaRect(cnt)
        x, y = center
        w, h = wh
        area = cv2.contourArea(cnt)
        area_min = 0.0003
        area_res = area/(r*c)
        temp = [100.0, 100.0, 100.0, 100.0]
        if str(mask) == 'red_mask':
                area_min = 0.0007
                area_max = 0.001
                color_send = 1.0
                frame_color = (0,255,0)
        elif str(mask) == 'blue_mask':
                area_min = 0.0017
                area_max = 0.007
                color_send = 2.0
                frame_color = (0,0,255)
        elif str(mask) == 'orange_mask':
                area_min = 0.0003
                area_max = 0.0005
                color_send = 3.0
                frame_color = (255,0,0)
        if area_res > area_min and area_res < 0.01 :
            if(w/h) > 0.9 and (w/h) < 1.1:
                xRes = 2*(x - int(c/2))/c
                yRes = -2*(y - int(r/2))/r
                box = cv2.boxPoints(rect)
                box = np.int0(box)
                blurred = cv2.drawContours(blurred, [box], 0, frame_color, 2)
                print('w/h', (w/h))
                print('x: ', xRes)
                print('y: ', yRes)
                print('area_res', area_res)
                temp = [xRes, yRes, area_res, color_send]
        return temp

def detector(img):

    red_upper = np.array([179, 255, 255])
    red_lower = np.array([141, 115, 110])

    blue_upper = np.array([129, 215, 255])
    blue_lower = np.array([95, 150, 171])

    orange_upper = np.array([50, 100, 255])
    orange_lower = np.array([0, 0, 180])

    area_res = -1
    area = 0
    wh = (-1, -1)
    w, h = wh

    kernel = cv2.getStructuringElement(cv2.MORPH_RECT, (5, 5))

    red_area_max = 0.001
    red_area_min = 0.0007

    blue_area_max = 0.0075
    blue_area_min = 0.0017

    orange_area_max = 0.0005
    orange_area_min = 0.0003

    if img is None:
        print('image is None, Please check camera.')
        return

    r, c, ch = img.shape
    blurred = cv2.GaussianBlur(img, (7, 7), 0)
    hsv = cv2.cvtColor(blurred, cv2.COLOR_BGR2HSV)

    red_mask = cv2.inRange(hsv, red_lower, red_upper)
    red_mask = cv2.dilate(red_mask, kernel)

    blue_mask = cv2.inRange(hsv, blue_lower, blue_upper)
    blue_mask = cv2.dilate(blue_mask, kernel)

    orange_mask = cv2.inRange(hsv, orange_lower, orange_upper)
    orange_mask = cv2.dilate(orange_mask, kernel)
    
    mask = red_mask + blue_mask + orange_mask

    msg = Float64MultiArray(data=findColor(red_mask, blurred))
    pub.publish(msg)
    msg = Float64MultiArray(data=findColor(blue_mask, blurred))
    pub.publish(msg)
    msg = Float64MultiArray(data=findColor(orange_mask, blurred))
    pub.publish(msg)

    bridge = CvBridge()
    imgMsg = bridge.cv2_to_imgmsg(blurred, "bgr8")
    imgPub.publish(imgMsg)
    maskMsg = bridge.cv2_to_imgmsg(mask, "mono8")
    maskPub.publish(maskMsg)
    rospy.Rate(30).sleep()
  #  cv2.imshow('res', blurred)
  #  cv2.imshow('mask', mask)

def listener():
    
    # rospy.init_node('image_pub',anonymous=True)
    rospy.init_node("detect",anonymous=True)
    rospy.Subscriber("/image_raw",Image,callback)
    rospy.spin()

def callback(data):

    msg = data
    bridge = CvBridge()
    frame = bridge.imgmsg_to_cv2(msg, "bgr8")
    detector(frame)

if __name__ == "__main__":
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
