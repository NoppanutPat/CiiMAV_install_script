#!/usr/bin/env python

import rospy
import sys
from std_msgs.msg import Float64MultiArray
import numpy as np
import pandas as pd

def listener():
    rospy.init_node("save_coor",anonymous=True)
    rospy.Subscriber("Coor",Float64MultiArray,callback)
    rospy.spin()

def callback(data):
    xRes,yRes,lat,lon,alt,color = data.data
    if color == 1:
        df = pd.read_csv("../../main_mission/src/data_red.csv")
        df.loc[len(df)] = [xRes,yRes,lat,lon,alt]
        df.to_csv("../../main_mission/src/data_red.csv",index=None)
    elif color == 2:
        df = pd.read_csv("../../main_mission/src/data_blue.csv")
        df.loc[len(df)] = [xRes,yRes,lat,lon,alt]
        df.to_csv("../../main_mission/src/data_blue.csv",index=None)
    elif color == 3:
        df = pd.read_csv("../../main_mission/src/data_orange.csv")
        df.loc[len(df)] = [xRes,yRes,lat,lon,alt]
        df.to_csv("../../main_mission/src/data_orange.csv",index=None)


if __name__ == "__main__":
    listener()
    
