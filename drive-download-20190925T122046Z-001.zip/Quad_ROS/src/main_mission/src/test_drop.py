from dronekit import connect, VehicleMode ,mavutil
from mission_lib import *
import time

connection_string = "/dev/ttyACM0"
baud_rate = 115200
vehicle = connect(connection_string, baud=baud_rate, wait_ready=True)
vehicle.wait_ready('autopilot_version')

print(dict(vehicle.channels))

#vehicle.channels.overrides["6"] = 964
#vehicle.channels.overrides["9"] = 2114

drop(vehicle,7,1900)
time.sleep(0.1)
drop(vehicle,8,1000)
time.sleep(3)
drop(vehicle,7,1000)
time.sleep(0.1)
drop(vehicle,8,1900)
