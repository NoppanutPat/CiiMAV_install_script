#!/usr/bin/env python

import sys
import rospy
from std_msgs.msg import Float64MultiArray
from dronekit import connect, VehicleMode
from mission_lib import *
from math import sin,cos,atan2,pi,sqrt
import numpy as np
import pandas as pd
import time

connection_string = "/dev/ttyACM0"
baud_rate = 115200
vehicle = connect(connection_string, baud=baud_rate, wait_ready=True)
vehicle.wait_ready('autopilot_version')

pub = rospy.Publisher("Coor",Float64MultiArray,queue_size=10)

first_time = 0
Finish_map = 0

def listener():
    rospy.init_node("go_to",anonymous=True)
    rospy.Subscriber("pic_xy",Float64MultiArray,callback)
    rospy.spin()

def callback(data):
    
    xRes , yRes, area_res , color = data.data
    yaw = 0
    yaw = Get_YAW(vehicle)

    poslat,poslon,Alt = get_GPSvalue(vehicle)
    if Alt < 10:
        return 0

    want_go = 0.0001

    if xRes == 100 and yRes == 100: #Can't find
        if vehicle.mode == "GUIDE" or vehicle.mode == "ALT_HOLD":
            vehicle.mode = VehicleMode("AUTO")
        else:
            return 0

    if abs(xRes) < 0.03 and abs(yRes) < 0.03:
        print(">>> Change mode to 'ALT_HOLD' <<<<")
  	vehicle.mode = VehicleMode("ALT_HOLD")
        Change_Alt(vehicle,10)
        print ">>>>>>>>>>>>>>>> DROPPP >>>>>>>>>>>>>>>>>"
        drop(vehicle,7,1900)
        time.sleep(0.1)
        drop(vehicle,8,1000)

    R = sqrt((xRes**2)+(yRes**2))

    # print "atan2(yRes,xRes) : ", (atan2(yRes,xRes)*180/pi)

    atann = atan2(yRes,xRes)

    # if atann < 0:
    #     atann += 2*pi

    if yaw > 0 and yaw <= pi/2:
        n_go = yRes*cos(yaw) - xRes*sin(yaw)
        e_go = yRes*sin(yaw) + xRes*cos(yaw)

    elif yaw > pi/2 and yaw <= pi:
        n_go = xRes*sin(2*pi-yaw) + yRes*cos(2*pi - yaw)
        e_go = xRes*cos(2*pi-yaw) - yRes*sin(2*pi - yaw)

    elif yaw > pi and yaw <= 3*pi/2:
        n_go = xRes*sin(yaw - pi) - yRes*cos(yaw - pi)
        e_go = -xRes*cos(yaw - pi) - yRes*sin(yaw - pi)

    elif yaw > 3*pi/2 and yaw < 2*pi:
        n_go = -xRes*cos(yaw - pi/2) - yRes*sin(yaw - pi/2)
        e_go = yRes*cos(yaw - pi/2) - xRes*sin(yaw - pi/2)

    elif yaw == 0:
        n_go = yRes
        e_go = xRes

    if abs(n_go) < 0.0000001:
        n_go = 0

    if abs(e_go) < 0.0000001:
        e_go = 0

    n_go = want_go * n_go
    e_go = want_go * e_go
    
    poslat,poslon,Alt = get_GPSvalue(vehicle)

    print "xRes , yRes : ",xRes," , ",yRes

    print "yaw : ",yaw

    print "n_want_go , e_want_go : ",n_go," , ",e_go

    print "n_go , e_go : ",n_go+poslat," , ",e_go+poslon

    print "--------------------------------------------------"



    if abs(xRes) > 0.05 and abs(yRes) > 0.05 and xRes != 100 and yRes != 100 :
        poslat,poslon,Alt = get_GPSvalue(vehicle)
        coor_data = [xRes,yRes,poslat+n_go,poslon+e_go,Alt,color]
        coor_data = Float64MultiArray(coor_data)
        pub.publish(coor_data)
        rospy.Rate(30).sleep()
            # saveCOOR(vehicle,xRes,yRes,poslat+n_go,poslon+e_go,Alt)
            # if Alt > 13:
            #     goto(vehicle, poslat+n_go,poslon+e_go,Alt-1)
            # else:
            #     goto(vehicle, poslat+n_go,poslon+e_go,Alt)

    if vehicle.mode.name == "AUTO" && Alt < 16:
        global Finish_map = 1

    if Finish_map == 1:
        if first_time == 0:
            df = pd.read_csv("data_red.csv")
            l_xRes = np.array(df["XRES"])
            l_yRes = np.array(df["YRES"])
            diff_Res = abs(l_yRes - lxRes)

            ans_index = diff_Res.index(min(diff_Res))

            poslat_go = df["LAT"][ans_index]
            poslon_go = df["LON"][ans_index]
            alt_go = df["ALT"][ans_index]

            if vehicle.mode == "AUTO" or vehicle.mode == "ALT_HOLD":
                goto(vehicle,poslat_go,poslon_go,alt_go)
                global first_time = 1
        
        else:
            if vehicle.mode == "AUTO" or vehicle.mode == "ALT_HOLD":
                if Alt > 13:
                    goto(vehicle, poslat+n_go,poslon+e_go,Alt-1)
                else:
                    goto(vehicle, poslat+n_go,poslon+e_go,Alt)



if __name__ == "__main__":
    Takeoff(vehicle,30)
    vehicle.mode = VehicleMode("AUTO")
    try:
        listener()
    except rospy.ROSInterruptException:
        pass
