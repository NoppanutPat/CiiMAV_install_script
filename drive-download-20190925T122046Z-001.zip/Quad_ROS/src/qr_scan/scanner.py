#!/usr/bin/env python

import rospy
from sensor_msgs.msg import Image
from cv_bridge import CvBridge
import cv2
import numpy as np
import pyzbar.pyzbar as pyzbar

def listener():
    rospy.init_node("scanner",anonymous=True)
    rospy.Subscriber("Video",Image,callback)
    rospy.spin()

def callback(data):
    msg = data
    bridge = CvBridge()
    frame = bridge.imgmsg_to_cv2(msg, "bgr8")
    qr_reader(frame)


def qr_reader(frame):

    im = cv2.cvtColor(frame, cv2.COLOR_RGB2GRAY)
    eq = cv2.equalizeHist(im)
    res = np.hstack((im, eq)) 

    cv2.imshow("res", res)
    decodedObjects = pyzbar.decode(res)
    for obj in decodedObjects:
        print("Data", obj.data)
        #cv2.putText(res, str(obj.data), (50, 50), font, 2,
                    #(255, 0, 0), 3)

    cv2.waitKey(1)


if __name__ == "__main__":
    listener()
